const https = require('https')

const fetch = (url, options, callback) => {
  const newURL = new URL(url)
  const type = options ? options.method ? options.method : 'GET' : 'GET'
  var options = {
    host: newURL.host,
    path: newURL.pathname + newURL.search + newURL.hash,
    method: type
  }
  if (options.promise==true) {
    return new Promise((resolve, reject) => {
      https.request(options, response => {
        let pData = []
        let sendData = ''
        response.on('data', (data) => {pData.push(data)}).on('end', () => {
          sendData = options.buffer ? Buffer.concat(pData) : Buffer.concat(pData).toString()
          resolve(sendData)
        })
      }).on('error', err => reject(err)).end()
    })
  } else {
    https.request(url, response => {
      let pData = []
      let sendData = ''
      response.on('data', (data) => {pData.push(data)}).on('end', () => {
        sendData = options.buffer ? Buffer.concat(pData) : Buffer.concat(pData).toString()
        callback(sendData)
      })
    }).on('error', err => console.log(err)).end()
  }
}

module.exports = fetch